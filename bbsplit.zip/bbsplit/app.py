#!/usr/bin/env python3
"""Entry point: python -m bbsplit  or  python app.py"""
from bbsplit.gui import main

if __name__ == "__main__":
    main()
