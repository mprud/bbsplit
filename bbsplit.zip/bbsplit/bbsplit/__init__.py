"""bbsplit — a tool for splitting molecules into building blocks and enumerating them."""
__version__ = "0.4.0"
