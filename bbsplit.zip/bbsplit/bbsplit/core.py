"""
bbsplit.core
============
Engine that splits molecules into building blocks using a base of
retrosynthetic SMARTS rules, plus reverse recombination (enumeration).

GUI-independent — fully testable headless.

Key concepts
------------
Rule          : a single retrosynthetic rule (name, SMARTS, priority, ...).
RuleSet       : a set of rules (default + custom), loaded from YAML.
BondCut       : one specific breakable bond in a molecule, together with the
                rule that matched it.
Disconnection : one way to cut a molecule (a set of 1..N bonds) -> a list of
                fragment blocks with dummy atoms [*N].
SplitEngine   : applies rules and generates all Disconnections up to max_bonds.
"""

from __future__ import annotations

import itertools
import os
from dataclasses import dataclass, field
from typing import Iterable, Sequence

import yaml
from rdkit import Chem
from rdkit import RDLogger

RDLogger.DisableLog("rdApp.*")

DEFAULT_RULES_PATH = os.path.join(os.path.dirname(__file__), "default_rules.yaml")


# --------------------------------------------------------------------------- #
#  Rules
# --------------------------------------------------------------------------- #
@dataclass
class Rule:
    name: str
    smarts: str
    priority: int = 50
    description: str = ""
    enabled: bool = True
    _patt: Chem.Mol = field(default=None, repr=False, compare=False)

    def __post_init__(self):
        self._patt = Chem.MolFromSmarts(self.smarts)
        if self._patt is None:
            raise ValueError(f"Invalid SMARTS in rule '{self.name}': {self.smarts}")

    @property
    def pattern(self) -> Chem.Mol:
        return self._patt


class RuleSet:
    """A collection of rules with YAML loading/merging."""

    def __init__(self, rules: Sequence[Rule] | None = None):
        self.rules: list[Rule] = list(rules or [])

    # ---- loading ----
    @classmethod
    def from_yaml(cls, path: str) -> "RuleSet":
        with open(path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        rules = [Rule(**r) for r in data.get("rules", [])]
        return cls(rules)

    @classmethod
    def default(cls) -> "RuleSet":
        return cls.from_yaml(DEFAULT_RULES_PATH)

    def merge_yaml(self, path: str, override: bool = True) -> None:
        """Add rules from a custom YAML. With override=True, rules with the
        same name replace existing ones; otherwise they are ignored."""
        extra = RuleSet.from_yaml(path)
        by_name = {r.name: r for r in self.rules}
        for r in extra.rules:
            if r.name in by_name and not override:
                continue
            by_name[r.name] = r
        self.rules = list(by_name.values())

    def to_yaml(self, path: str) -> None:
        data = {"rules": [
            {"name": r.name, "smarts": r.smarts, "priority": r.priority,
             "description": r.description, "enabled": r.enabled}
            for r in self.rules
        ]}
        with open(path, "w", encoding="utf-8") as fh:
            yaml.safe_dump(data, fh, allow_unicode=True, sort_keys=False)

    def enabled_rules(self) -> list[Rule]:
        return sorted([r for r in self.rules if r.enabled],
                      key=lambda r: -r.priority)

    def __len__(self):
        return len(self.rules)


# --------------------------------------------------------------------------- #
#  Result structures
# --------------------------------------------------------------------------- #
@dataclass(frozen=True)
class BondCut:
    """One breakable bond: bond index + the rule that matched it."""
    bond_idx: int
    begin_atom: int
    end_atom: int
    rule_name: str
    priority: int


@dataclass
class Disconnection:
    """One way to cut a molecule (1..N bonds)."""
    cuts: tuple[BondCut, ...]
    fragments: list[str]          # canonical block SMILES with [*N]
    rule_names: tuple[str, ...]

    @property
    def n_bonds(self) -> int:
        return len(self.cuts)

    @property
    def n_blocks(self) -> int:
        return len(self.fragments)

    def label(self) -> str:
        return " + ".join(sorted(set(self.rule_names)))


# --------------------------------------------------------------------------- #
#  Engine
# --------------------------------------------------------------------------- #
class SplitEngine:
    def __init__(self, ruleset: RuleSet, max_bonds: int = 2):
        self.ruleset = ruleset
        self.max_bonds = max_bonds

    # ---- step 1: find all breakable bonds ----
    def find_cuts(self, mol: Chem.Mol) -> list[BondCut]:
        """All unique bonds matched by at least one rule. If several rules match
        the same bond, keep the one with the highest priority."""
        best: dict[int, BondCut] = {}
        for rule in self.ruleset.enabled_rules():
            for match in mol.GetSubstructMatches(rule.pattern):
                if len(match) < 2:
                    continue
                a1, a2 = match[0], match[1]
                bond = mol.GetBondBetweenAtoms(a1, a2)
                if bond is None or bond.IsInRing():
                    continue
                bidx = bond.GetIdx()
                cur = best.get(bidx)
                if cur is None or rule.priority > cur.priority:
                    best[bidx] = BondCut(
                        bond_idx=bidx, begin_atom=a1, end_atom=a2,
                        rule_name=rule.name, priority=rule.priority,
                    )
        return sorted(best.values(), key=lambda c: (-c.priority, c.bond_idx))

    # ---- step 2: fragment on a specific set of bonds ----
    @staticmethod
    def _fragment(mol: Chem.Mol, bond_indices: Sequence[int]) -> list[str] | None:
        try:
            frag = Chem.FragmentOnBonds(mol, list(bond_indices), addDummies=True)
            parts = Chem.GetMolFrags(frag, asMols=True, sanitizeFrags=True)
        except Exception:
            return None
        return [Chem.MolToSmiles(p) for p in parts]

    # ---- step 3: all ways to cut the molecule ----
    def disconnect(self, smiles: str) -> list[Disconnection]:
        mol = Chem.MolFromSmiles(smiles)
        if mol is None:
            return []
        cuts = self.find_cuts(mol)
        if not cuts:
            return []

        results: list[Disconnection] = []
        seen_fragsets: set[frozenset] = set()

        # combinations of 1..max_bonds bonds
        for k in range(1, self.max_bonds + 1):
            for combo in itertools.combinations(cuts, k):
                bidx = [c.bond_idx for c in combo]
                frags = self._fragment(mol, bidx)
                if frags is None:
                    continue
                # k cuts must yield exactly k+1 fragments (else ring/overlap)
                if len(frags) != k + 1:
                    continue
                key = frozenset(frags + [str(sorted(bidx))])
                if key in seen_fragsets:
                    continue
                seen_fragsets.add(key)
                results.append(Disconnection(
                    cuts=combo,
                    fragments=frags,
                    rule_names=tuple(c.rule_name for c in combo),
                ))
        # sort: simpler first (fewer blocks), then by total priority
        results.sort(key=lambda d: (d.n_blocks, -sum(c.priority for c in d.cuts)))
        return results


# --------------------------------------------------------------------------- #
#  Recombination / enumeration
# --------------------------------------------------------------------------- #
def _dummy_atoms(mol: Chem.Mol) -> list[int]:
    return [a.GetIdx() for a in mol.GetAtoms() if a.GetAtomicNum() == 0]


def _anchor_of(mol: Chem.Mol, dummy_idx: int) -> int | None:
    nbrs = mol.GetAtomWithIdx(dummy_idx).GetNeighbors()
    return nbrs[0].GetIdx() if nbrs else None


def combine_two(smiles_a: str, smiles_b: str) -> str | None:
    """Stitch ONE dummy atom of block A to ONE dummy atom of block B.
    Suitable for blocks that have exactly one [*] each."""
    a = Chem.MolFromSmiles(smiles_a)
    b = Chem.MolFromSmiles(smiles_b)
    if a is None or b is None:
        return None
    combo = Chem.RWMol(Chem.CombineMols(a, b))
    dummies = _dummy_atoms(combo)
    if len(dummies) != 2:
        return None
    anchors = [_anchor_of(combo, d) for d in dummies]
    if None in anchors:
        return None
    combo.AddBond(anchors[0], anchors[1], Chem.BondType.SINGLE)
    for d in sorted(dummies, reverse=True):
        combo.RemoveAtom(d)
    try:
        m = combo.GetMol()
        Chem.SanitizeMol(m)
        return Chem.MolToSmiles(m)
    except Exception:
        return None


def enumerate_blocks(block_lists: Sequence[Sequence[str]],
                     dedup: bool = True) -> list[dict]:
    """
    Cartesian enumeration for the two-role case (2 block lists).
    Each block must contain exactly one [*]. Returns a list of dict rows.

    For 3-block cuts use enumerate_linear (below).
    """
    if len(block_lists) != 2:
        raise ValueError("enumerate_blocks expects exactly 2 block lists. "
                         "For 3 blocks call enumerate_linear().")
    rows, seen = [], set()
    a_list, b_list = block_lists
    for i, a in enumerate(a_list):
        for j, b in enumerate(b_list):
            prod = combine_two(a, b)
            if prod is None:
                continue
            if dedup and prod in seen:
                continue
            seen.add(prod)
            rows.append({"a_idx": i, "b_idx": j,
                         "blockA": a, "blockB": b, "product": prod})
    return rows


def enumerate_linear(block_lists: Sequence[Sequence[str]],
                     dedup: bool = True) -> list[dict]:
    """
    Sequential (linear) enumeration for cuts into >2 blocks.
    Assumes the blocks form a chain: the central block has 2 [*], the
    terminal ones have 1 each. Stitched sequentially left to right.

    For simplicity and predictability the stitching follows the order
    block_lists[0] - block_lists[1] - ..., where each next block attaches to
    the first free [*] of the current product.
    """
    rows, seen = [], set()
    for combo in itertools.product(*[range(len(bl)) for bl in block_lists]):
        chosen = [block_lists[k][idx] for k, idx in enumerate(combo)]
        prod = _chain_combine(chosen)
        if prod is None:
            continue
        if dedup and prod in seen:
            continue
        seen.add(prod)
        row = {f"block{k}": s for k, s in enumerate(chosen)}
        row["product"] = prod
        rows.append(row)
    return rows


def _chain_combine(smiles_list: Sequence[str]) -> str | None:
    """Sequentially stitch a list of blocks by their dummy atoms. At each step
    join the first free [*] of the accumulator to the [*] of the next block."""
    if not smiles_list:
        return None
    acc = Chem.MolFromSmiles(smiles_list[0])
    if acc is None:
        return None
    for nxt_smi in smiles_list[1:]:
        nxt = Chem.MolFromSmiles(nxt_smi)
        if nxt is None:
            return None
        rw = Chem.RWMol(Chem.CombineMols(acc, nxt))
        dummies = _dummy_atoms(rw)
        # connect one dummy from the acc part and one from the nxt part.
        n_acc = acc.GetNumAtoms()
        acc_dummies = [d for d in dummies if d < n_acc]
        nxt_dummies = [d for d in dummies if d >= n_acc]
        if not acc_dummies or not nxt_dummies:
            return None
        d_acc, d_nxt = acc_dummies[0], nxt_dummies[0]
        a_acc, a_nxt = _anchor_of(rw, d_acc), _anchor_of(rw, d_nxt)
        if a_acc is None or a_nxt is None:
            return None
        rw.AddBond(a_acc, a_nxt, Chem.BondType.SINGLE)
        for d in sorted([d_acc, d_nxt], reverse=True):
            rw.RemoveAtom(d)
        try:
            acc = rw.GetMol()
            Chem.SanitizeMol(acc)
        except Exception:
            return None
    return Chem.MolToSmiles(acc)
