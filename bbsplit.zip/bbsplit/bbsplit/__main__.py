from bbsplit.gui import main
main()
