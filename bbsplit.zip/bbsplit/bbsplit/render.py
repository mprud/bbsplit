"""
bbsplit.render
==============
Render SMILES to images for the GUI (RDKit -> PNG bytes -> QPixmap).
Kept separate so the core does not depend on Qt.
"""

from __future__ import annotations
from rdkit import Chem
from rdkit.Chem.Draw import rdMolDraw2D


def smiles_to_png(smiles: str, width: int = 260, height: int = 180) -> bytes | None:
    """Return PNG bytes for a SMILES (supports dummy atoms [*])."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    d = rdMolDraw2D.MolDraw2DCairo(width, height)
    opts = d.drawOptions()
    opts.dummiesAreAttachments = False  # show [*] explicitly
    try:
        rdMolDraw2D.PrepareAndDrawMolecule(d, mol)
        d.FinishDrawing()
        return d.GetDrawingText()
    except Exception:
        return None
