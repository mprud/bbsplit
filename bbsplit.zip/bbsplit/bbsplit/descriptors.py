"""
bbsplit.descriptors
====================
Compute common molecular descriptors for enumerated products.

Descriptors are returned as a plain dict per molecule so they can be added to
result rows, shown in a sortable table, and written to CSV. All values are
numeric (float/int) or None when a molecule cannot be parsed.

Descriptor set (Lipinski / lead-likeness oriented):
    MW      - molecular weight (g/mol)
    LogP    - Crippen cLogP
    HBD     - H-bond donors
    HBA     - H-bond acceptors
    TPSA    - topological polar surface area (A^2)
    RotB    - rotatable bonds
    Rings   - ring count
    ArRings - aromatic ring count
    HAC     - heavy atom count
    FCsp3   - fraction of sp3 carbons
"""

from __future__ import annotations

from rdkit import Chem
from rdkit.Chem import Descriptors, Lipinski, rdMolDescriptors, Crippen

# Order is significant: it is used for table columns and CSV field order.
DESCRIPTOR_FIELDS = [
    "MW", "LogP", "HBD", "HBA", "TPSA",
    "RotB", "Rings", "ArRings", "HAC", "FCsp3",
]

# Fields that should be displayed/handled as integers.
INT_FIELDS = {"HBD", "HBA", "RotB", "Rings", "ArRings", "HAC"}


def compute_descriptors(smiles: str) -> dict:
    """Return a dict of descriptors for one SMILES (all None on parse failure)."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {f: None for f in DESCRIPTOR_FIELDS}
    return {
        "MW": round(Descriptors.MolWt(mol), 2),
        "LogP": round(Crippen.MolLogP(mol), 2),
        "HBD": Lipinski.NumHDonors(mol),
        "HBA": Lipinski.NumHAcceptors(mol),
        "TPSA": round(rdMolDescriptors.CalcTPSA(mol), 2),
        "RotB": Lipinski.NumRotatableBonds(mol),
        "Rings": rdMolDescriptors.CalcNumRings(mol),
        "ArRings": rdMolDescriptors.CalcNumAromaticRings(mol),
        "HAC": mol.GetNumHeavyAtoms(),
        "FCsp3": round(rdMolDescriptors.CalcFractionCSP3(mol), 3),
    }


def annotate_rows(rows: list[dict], smiles_key: str = "product") -> list[dict]:
    """Add descriptor fields to each row in place and return the list."""
    for r in rows:
        smi = r.get(smiles_key)
        if smi:
            r.update(compute_descriptors(smi))
    return rows
