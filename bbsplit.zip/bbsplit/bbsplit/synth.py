"""
bbsplit.synth
=============
Synthetic-accessibility scoring for enumerated products.

Background
----------
The original request was to integrate RAScore
(https://github.com/reymond-group/RAscore), which predicts the probability that
a computer-aided synthesis-planning tool can find a route to a molecule.

RAScore, however, pins hard, legacy dependencies (python==3.7/3.8,
scikit-learn==0.22.1, xgboost==1.0.2, tensorflow==2.5.0) that are incompatible
with bbsplit's modern stack (Python >=3.10, current RDKit, PySide6). Installing
it into the same environment breaks RDKit/PySide6.

So bbsplit uses the **SAScore** (Synthetic Accessibility score of Ertl &
Schuffenhauer, J. Cheminform. 2009) shipped with RDKit's Contrib directory. It
is dependency-free, fast, and gives a practical estimate of how hard a molecule
is to synthesise:

    SAScore scale: 1.0 (easy to make)  ...  10.0 (hard to make)

A normalised "ease" value in [0, 1] is also provided (1 = easy, 0 = hard), which
is convenient for colouring/sorting where "higher = better".

If a user has a working RAScore environment, `score_rascore()` will use it when
available and otherwise fall back gracefully to SAScore.
"""

from __future__ import annotations

import os
import sys

from rdkit import Chem
from rdkit.Chem import RDConfig

# ---- SAScore (RDKit Contrib) ------------------------------------------------
_SA_OK = False
try:
    sys.path.append(os.path.join(RDConfig.RDContribDir, "SA_Score"))
    import sascorer  # type: ignore
    _SA_OK = True
except Exception:  # pragma: no cover
    sascorer = None  # type: ignore
    _SA_OK = False

# ---- Optional RAScore (only if the user's env happens to provide it) --------
_RA_SCORER = None
_RA_OK = False
try:  # pragma: no cover - depends on external optional package
    from RAscore import RAscore_XGB  # type: ignore
    _RA_SCORER = RAscore_XGB.RAScorerXGB()
    _RA_OK = True
except Exception:
    _RA_SCORER = None
    _RA_OK = False


SA_MIN, SA_MAX = 1.0, 10.0


def sascore_available() -> bool:
    return _SA_OK


def rascore_available() -> bool:
    return _RA_OK


def sa_score(smiles: str) -> float | None:
    """Raw SAScore in [1, 10] (1 = easy, 10 = hard). None on failure."""
    if not _SA_OK:
        return None
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None
    try:
        return round(float(sascorer.calculateScore(mol)), 2)
    except Exception:
        return None


def sa_ease(smiles: str) -> float | None:
    """Normalised ease in [0, 1] derived from SAScore (1 = easy, 0 = hard)."""
    sa = sa_score(smiles)
    if sa is None:
        return None
    clamped = max(SA_MIN, min(SA_MAX, sa))
    return round((SA_MAX - clamped) / (SA_MAX - SA_MIN), 3)


def score_rascore(smiles: str) -> float | None:
    """RAScore probability in [0, 1] (1 = easy/route found). Uses RAScore if the
    environment provides it; otherwise returns None (caller may use SAScore)."""
    if not _RA_OK:
        return None
    try:
        return round(float(_RA_SCORER.predict(smiles)), 4)
    except Exception:
        return None


# Fields this module contributes to a result row, in display order.
SYNTH_FIELDS = ["SAscore", "SA_ease"]
SYNTH_INT_FIELDS: set[str] = set()


def annotate_synth(rows: list[dict], smiles_key: str = "product") -> list[dict]:
    """Add SAscore (and SA_ease) to each row in place. If a real RAScore env is
    present, also add an 'RAscore' column."""
    add_ra = _RA_OK
    for r in rows:
        smi = r.get(smiles_key)
        if not smi:
            continue
        r["SAscore"] = sa_score(smi)
        r["SA_ease"] = sa_ease(smi)
        if add_ra:
            r["RAscore"] = score_rascore(smi)
    if add_ra and "RAscore" not in SYNTH_FIELDS:
        SYNTH_FIELDS.append("RAscore")
    return rows
