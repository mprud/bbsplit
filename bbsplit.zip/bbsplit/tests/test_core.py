"""Basic core tests — run: pytest -q"""
from bbsplit.core import (
    RuleSet, SplitEngine, combine_two, enumerate_blocks,
)

M1 = "NC(c(cc(cc1)NCc2cc(Cl)cc(Cl)c2)c1F)=O"
M2 = "NC(c1cc(OCc(cc2)ccc2SC(F)F)cnc1)=O"
M3 = "CCC(Nc1cccc(C(N)=O)n1)c1ccc(Cl)c(Cl)c1"


def engine():
    return SplitEngine(RuleSet.default(), max_bonds=2)


def test_rules_load():
    rs = RuleSet.default()
    assert len(rs) >= 5
    assert any(r.name == "amide_CN" for r in rs.rules)


def test_disconnect_finds_multiple_ways():
    eng = engine()
    discs = eng.disconnect(M1)
    assert len(discs) >= 2
    # both amide and amine-alkylation should be among the results
    names = {n for d in discs for n in d.rule_names}
    assert "amide_CN" in names
    assert "amine_alkylation_NC" in names


def test_ether_fallback_on_m2():
    eng = engine()
    discs = eng.disconnect(M2)
    names = {n for d in discs for n in d.rule_names}
    assert "ether_OC" in names


def test_roundtrip_m3():
    """Amine-alkylation cut + reverse stitching reproduces the input molecule."""
    from rdkit import Chem
    eng = engine()
    target = Chem.MolToSmiles(Chem.MolFromSmiles(M3))
    for d in eng.disconnect(M3):
        if d.n_blocks == 2 and "amine_alkylation_NC" in d.rule_names:
            prod = combine_two(d.fragments[0], d.fragments[1])
            assert prod == target
            return
    raise AssertionError("No amine-alkylation cut found for M3")


def test_enumerate_cartesian():
    A = ["[8*]Nc1ccc(F)c(C(N)=O)c1", "[2*]Nc1cccc(C(N)=O)n1"]
    B = ["[7*]Cc1cc(Cl)cc(Cl)c1", "[5*]Cc1ccc(SC(F)F)cc1"]
    rows = enumerate_blocks([A, B], dedup=True)
    assert len(rows) == 4
    assert all(r["product"] for r in rows)


def test_descriptors():
    from bbsplit.descriptors import compute_descriptors, DESCRIPTOR_FIELDS
    d = compute_descriptors(M3)
    assert set(DESCRIPTOR_FIELDS).issubset(d.keys())
    assert d["MW"] > 0 and d["HBA"] >= 1
    # parse failure yields all-None
    bad = compute_descriptors("not_a_smiles")
    assert all(v is None for v in bad.values())


def test_enum_id_format():
    import re
    from bbsplit.gui import make_enum_id  # pure helper, safe to import
    eid = make_enum_id(1)
    assert re.match(r"^[A-Za-z]{3,}\d+$", eid)
    assert eid == "ENU0001"


def test_io_smiles_lines(tmp_path):
    from bbsplit import io_formats
    p = tmp_path / "x.smi"
    p.write_text("c1ccccc1 benzene\nCCO ethanol\n", encoding="utf-8")
    items = io_formats.detect_and_read(str(p))
    assert items == [("benzene", "c1ccccc1"), ("ethanol", "CCO")]


def test_io_sdf(tmp_path):
    from rdkit import Chem
    from bbsplit import io_formats
    p = tmp_path / "x.sdf"
    w = Chem.SDWriter(str(p))
    m = Chem.MolFromSmiles("CCO"); m.SetProp("_Name", "eth"); w.write(m)
    w.close()
    items = io_formats.detect_and_read(str(p))
    assert len(items) == 1 and items[0][0] == "eth"


def test_parallel_matches_serial():
    from bbsplit.parallel import split_molecules
    mols = [(f"m{i}", M3) for i in range(6)]
    s1 = split_molecules(mols, RuleSet.default(), max_bonds=2, workers=1)
    s4 = split_molecules(mols, RuleSet.default(), max_bonds=2, workers=4)
    for k in s1:
        assert [d.fragments for d in s1[k]] == [d.fragments for d in s4[k]]


def test_expanded_ruleset_size():
    rs = RuleSet.default()
    assert len(rs) >= 12  # expanded rule base
