#!/usr/bin/env python3
"""
bbsplit CLI — headless alternative to the GUI.

Runs the same core without windows: splits molecules from a CSV and performs a
full Cartesian A×B enumeration over all 2-block disconnections. Splitting and
enumeration can run in parallel. Useful for batch processing, servers and CI.

Example:
    python cli.py examples/sample_input.csv --smiles-col SMILES --id-col ID \
        --max-bonds 2 --workers 4 --out enumerated.csv
"""

from __future__ import annotations
import argparse
import csv

from rdkit import Chem

from bbsplit.core import RuleSet
from bbsplit.parallel import split_molecules, enumerate_blocks_parallel
from bbsplit.descriptors import annotate_rows, DESCRIPTOR_FIELDS


def role_of(frag: str) -> str:
    """Role A if the dummy-atom neighbour is a heteroatom (N/O), else role B."""
    m = Chem.MolFromSmiles(frag)
    if m is None:
        return "B"
    for at in m.GetAtoms():
        if at.GetAtomicNum() == 0:
            nb = at.GetNeighbors()
            return "A" if (nb and nb[0].GetSymbol() in ("N", "O")) else "B"
    return "B"


def is_trivial(frag: str) -> bool:
    return sum(1 for ch in frag if ch.isalpha() and ch != "*") <= 1


def main():
    ap = argparse.ArgumentParser(
        description="Split molecules into building blocks and enumerate A×B.")
    ap.add_argument("input", help="Input file: .csv, .smi, .txt, .sdf or .mol")
    ap.add_argument("--smiles-col", default="SMILES",
                    help="SMILES column name (CSV only).")
    ap.add_argument("--id-col", default=None, help="ID column name (CSV only).")
    ap.add_argument("--max-bonds", type=int, default=2)
    ap.add_argument("--rules", default=None, help="Custom YAML rules to merge.")
    ap.add_argument("--workers", type=int, default=1,
                    help="Parallel workers: 1=serial, N>1=processes, 0=all CPUs.")
    ap.add_argument("--sort-by", default=None,
                    help="Descriptor to sort products by (e.g. MW, LogP, TPSA).")
    ap.add_argument("--descending", action="store_true",
                    help="Sort in descending order (with --sort-by).")
    ap.add_argument("--out", default="enumerated.csv")
    args = ap.parse_args()

    rs = RuleSet.default()
    if args.rules:
        rs.merge_yaml(args.rules, override=True)

    import os
    from bbsplit import io_formats
    ext = os.path.splitext(args.input)[1].lower()
    if ext == ".csv":
        molecules = io_formats.read_csv(args.input, args.smiles_col, args.id_col)
    else:
        molecules = io_formats.detect_and_read(args.input)

    # parallel splitting
    disc_map = split_molecules(molecules, rs,
                               max_bonds=args.max_bonds, workers=args.workers)

    pool_a, pool_b = set(), set()
    for discs in disc_map.values():
        for d in discs:
            if d.n_blocks != 2:
                continue
            for frag in d.fragments:
                if is_trivial(frag):
                    continue
                (pool_a if role_of(frag) == "A" else pool_b).add(frag)

    pa, pb = sorted(pool_a), sorted(pool_b)

    # parallel enumeration
    products = enumerate_blocks_parallel(pa, pb, dedup=True, workers=args.workers)

    # descriptors + stable IDs (>=3 letters + digits)
    annotate_rows(products, smiles_key="product")
    for i, p in enumerate(products, start=1):
        p["ID"] = f"ENU{i:04d}"

    # optional sort by a descriptor
    if args.sort_by:
        if args.sort_by not in DESCRIPTOR_FIELDS:
            ap_err = ", ".join(DESCRIPTOR_FIELDS)
            raise SystemExit(f"--sort-by must be one of: {ap_err}")
        products.sort(
            key=lambda r: (r.get(args.sort_by) is None, r.get(args.sort_by)),
            reverse=args.descending)
        # re-number IDs to follow the sorted order
        for i, p in enumerate(products, start=1):
            p["ID"] = f"ENU{i:04d}"

    fields = ["ID", "blockA", "blockB", "product"] + DESCRIPTOR_FIELDS
    with open(args.out, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(products)

    print(f"A blocks={len(pa)}, B blocks={len(pb)}; "
          f"enumerated {len(products)} products -> {args.out}")


if __name__ == "__main__":
    main()
